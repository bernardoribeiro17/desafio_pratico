import React from 'react';
import { Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Toast from './components/Toast';
import Home from './pages/Home';
import Produtos from './pages/Produtos';
import Contato from './pages/Contato';

const App: React.FC = () => {
  return (
    <div>
      <NavBar />
      <main className="container mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/produtos" element={<Produtos />} />
          <Route path="/contato" element={<Contato />} />
        </Routes>
      </main>
      <Toast />
    </div>
  );
};

export default App;
