import React from 'react';
import { useCarrinho } from '../context/CarrinhoContext';

const Carrinho: React.FC = () => {
  const { itens, totalValor, limparCarrinho, finalizarCompra } = useCarrinho();

  return (
    <div className="container mt-5" id="carrinho">
      <h3 className="mb-4">Carrinho de Compras</h3>

      <ul className="list-group shadow-sm mb-3">
        {itens.length === 0 ? (
          <li className="list-group-item text-muted fst-italic">
            Nenhum item no carrinho.
          </li>
        ) : (
          itens.map((item) => (
            <li
              key={item.nome}
              className="list-group-item d-flex justify-content-between align-items-center"
            >
              <span>
                {item.nome}{' '}
                <span className="badge bg-secondary ms-1">x{item.qtd}</span>
              </span>
              <span>
                R${' '}
                {(item.preco * item.qtd).toLocaleString('pt-BR', {
                  minimumFractionDigits: 2,
                })}
              </span>
            </li>
          ))
        )}
      </ul>

      <div className="alert alert-info d-flex align-items-center">
        <h5 className="m-0">
          Total: R${' '}
          {totalValor.toLocaleString('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </h5>
        <div className="ms-auto d-flex gap-2">
          <button
            type="button"
            className="btn btn-success btn-sm"
            onClick={finalizarCompra}
          >
            Finalizar Compra
          </button>
          <button
            type="button"
            className="btn btn-danger btn-sm"
            onClick={limparCarrinho}
          >
            Limpar Carrinho
          </button>
        </div>
      </div>
    </div>
  );
};

export default Carrinho;
