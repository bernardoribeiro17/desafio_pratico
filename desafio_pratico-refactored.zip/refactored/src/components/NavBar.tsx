import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useCarrinho } from '../context/CarrinhoContext';
import { useTheme } from '../context/ThemeContext';

const NavBar: React.FC = () => {
  const { totalItens } = useCarrinho();
  const { themeLabel, setTheme, toggleTheme } = useTheme();

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">
          TechStore
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#menu"
          aria-controls="menu"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="menu">
          <ul className="navbar-nav ms-auto align-items-center">
            <li className="nav-item">
              <NavLink className="nav-link" to="/" end>
                Home
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/produtos">
                Produtos
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/contato">
                Contato
              </NavLink>
            </li>

            <li className="nav-item d-flex align-items-center gap-2 ms-3">
              <button
                type="button"
                className="btn btn-sm btn-theme-light"
                onClick={() => setTheme('default')}
              >
                Claro
              </button>
              <button
                type="button"
                className="btn btn-sm btn-theme-dark"
                onClick={() => setTheme('dark')}
              >
                Escuro
              </button>
              <button
                type="button"
                className="btn btn-sm btn-theme-toggle"
                onClick={toggleTheme}
              >
                🎨 Tema: {themeLabel}
              </button>
            </li>

            <li className="nav-item ms-2">
              <NavLink className="nav-link" to="/produtos">
                Carrinho 🛒
                <span className="badge bg-danger ms-1">{totalItens}</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
