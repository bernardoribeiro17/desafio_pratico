import React from 'react';
import { useCarrinho } from '../context/CarrinhoContext';

const Toast: React.FC = () => {
  const { toastVisivel, esconderToast } = useCarrinho();

  if (!toastVisivel) return null;

  return (
    <div
      className="position-fixed bottom-0 end-0 p-3"
      style={{ zIndex: 11 }}
      role="alert"
      aria-live="assertive"
      aria-atomic="true"
    >
      <div className="toast show align-items-center text-bg-success border-0">
        <div className="d-flex">
          <div className="toast-body">Produto adicionado ao carrinho 🛒</div>
          <button
            type="button"
            className="btn-close btn-close-white me-2 m-auto"
            aria-label="Fechar"
            onClick={esconderToast}
          />
        </div>
      </div>
    </div>
  );
};

export default Toast;
