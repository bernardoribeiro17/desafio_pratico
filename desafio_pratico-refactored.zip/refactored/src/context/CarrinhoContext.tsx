import React, { createContext, useContext, useReducer, useEffect } from 'react';

export interface Produto {
  nome: string;
  preco: number;
  qtd: number;
}

interface CarrinhoState {
  itens: Produto[];
  toastVisivel: boolean;
}

type CarrinhoAction =
  | { type: 'ADICIONAR'; produto: Omit<Produto, 'qtd'>; qtd: number }
  | { type: 'LIMPAR' }
  | { type: 'FINALIZAR' }
  | { type: 'MOSTRAR_TOAST' }
  | { type: 'ESCONDER_TOAST' };

const carrinhoReducer = (state: CarrinhoState, action: CarrinhoAction): CarrinhoState => {
  switch (action.type) {
    case 'ADICIONAR': {
      const existente = state.itens.find((i) => i.nome === action.produto.nome);
      const novosItens = existente
        ? state.itens.map((i) =>
            i.nome === action.produto.nome ? { ...i, qtd: i.qtd + action.qtd } : i
          )
        : [...state.itens, { ...action.produto, qtd: action.qtd }];
      return { ...state, itens: novosItens, toastVisivel: true };
    }
    case 'LIMPAR':
      return { ...state, itens: [] };
    case 'FINALIZAR':
      return { ...state, itens: [] };
    case 'MOSTRAR_TOAST':
      return { ...state, toastVisivel: true };
    case 'ESCONDER_TOAST':
      return { ...state, toastVisivel: false };
    default:
      return state;
  }
};

const carregarDoLocalStorage = (): Produto[] => {
  try {
    return JSON.parse(localStorage.getItem('carrinho') || '[]');
  } catch {
    return [];
  }
};

interface CarrinhoContextType {
  itens: Produto[];
  toastVisivel: boolean;
  totalItens: number;
  totalValor: number;
  adicionarAoCarrinho: (produto: Omit<Produto, 'qtd'>, qtd: number) => void;
  limparCarrinho: () => void;
  finalizarCompra: () => void;
  esconderToast: () => void;
}

const CarrinhoContext = createContext<CarrinhoContextType | null>(null);

export const CarrinhoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(carrinhoReducer, {
    itens: carregarDoLocalStorage(),
    toastVisivel: false,
  });

  useEffect(() => {
    localStorage.setItem('carrinho', JSON.stringify(state.itens));
  }, [state.itens]);

  useEffect(() => {
    if (state.toastVisivel) {
      const timer = setTimeout(() => dispatch({ type: 'ESCONDER_TOAST' }), 3000);
      return () => clearTimeout(timer);
    }
  }, [state.toastVisivel]);

  const totalItens = state.itens.reduce((s, i) => s + i.qtd, 0);
  const totalValor = state.itens.reduce((s, i) => s + i.preco * i.qtd, 0);

  const adicionarAoCarrinho = (produto: Omit<Produto, 'qtd'>, qtd: number) =>
    dispatch({ type: 'ADICIONAR', produto, qtd });

  const limparCarrinho = () => dispatch({ type: 'LIMPAR' });

  const finalizarCompra = () => {
    if (state.itens.length === 0) {
      alert('Seu carrinho está vazio!');
      return;
    }
    alert('Compra realizada com sucesso! 🛒');
    dispatch({ type: 'FINALIZAR' });
  };

  const esconderToast = () => dispatch({ type: 'ESCONDER_TOAST' });

  return (
    <CarrinhoContext.Provider
      value={{
        itens: state.itens,
        toastVisivel: state.toastVisivel,
        totalItens,
        totalValor,
        adicionarAoCarrinho,
        limparCarrinho,
        finalizarCompra,
        esconderToast,
      }}
    >
      {children}
    </CarrinhoContext.Provider>
  );
};

export const useCarrinho = (): CarrinhoContextType => {
  const ctx = useContext(CarrinhoContext);
  if (!ctx) throw new Error('useCarrinho deve ser usado dentro de CarrinhoProvider');
  return ctx;
};
