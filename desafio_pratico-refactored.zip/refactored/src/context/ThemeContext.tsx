import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export type Theme = 'default' | 'dark' | 'green' | 'solar' | 'frost';

const THEMES: Theme[] = ['default', 'dark', 'green', 'solar', 'frost'];
const THEME_KEY = 'tech-store-theme';

const THEME_LABELS: Record<Theme, string> = {
  default: 'Azul/Laranja',
  dark: 'Escuro',
  green: 'Verde',
  solar: 'Solar',
  frost: 'Frost',
};

interface ThemeContextType {
  theme: Theme;
  themeLabel: string;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    return (localStorage.getItem(THEME_KEY) as Theme) || 'default';
  });

  const applyTheme = useCallback((t: Theme) => {
    const html = document.documentElement;
    if (t === 'default') {
      html.removeAttribute('class');
    } else {
      html.className = `theme-${t}`;
    }
    localStorage.setItem(THEME_KEY, t);
  }, []);

  useEffect(() => {
    applyTheme(theme);
  }, [theme, applyTheme]);

  const setTheme = (t: Theme) => setThemeState(t);

  const toggleTheme = () => {
    setThemeState((current) => {
      const idx = THEMES.indexOf(current);
      return THEMES[(idx + 1) % THEMES.length];
    });
  };

  return (
    <ThemeContext.Provider
      value={{ theme, themeLabel: THEME_LABELS[theme], setTheme, toggleTheme }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme deve ser usado dentro de ThemeProvider');
  return ctx;
};
