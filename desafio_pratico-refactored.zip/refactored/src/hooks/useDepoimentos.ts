import { useState, useEffect } from 'react';

export interface Depoimento {
  id: number;
  name: string;
  body: string;
}

interface UseDepoimentosReturn {
  depoimentos: Depoimento[];
  carregando: boolean;
  erro: string | null;
}

export const useDepoimentos = (): UseDepoimentosReturn => {
  const [depoimentos, setDepoimentos] = useState<Depoimento[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    let cancelado = false;

    const carregar = async () => {
      try {
        const resposta = await fetch(
          'https://jsonplaceholder.typicode.com/comments?_limit=3'
        );
        if (!resposta.ok) throw new Error('Falha ao buscar depoimentos');
        const dados: Depoimento[] = await resposta.json();
        if (!cancelado) setDepoimentos(dados);
      } catch (e) {
        if (!cancelado) setErro('Erro ao carregar depoimentos.');
      } finally {
        if (!cancelado) setCarregando(false);
      }
    };

    carregar();
    return () => { cancelado = true; };
  }, []);

  return { depoimentos, carregando, erro };
};
