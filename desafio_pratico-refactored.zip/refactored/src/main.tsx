import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { CarrinhoProvider } from './context/CarrinhoContext';
import { ThemeProvider } from './context/ThemeContext';
import './styles/main.scss';

const container = document.getElementById('root');
if (container) {
  createRoot(container).render(
    <React.StrictMode>
      <BrowserRouter>
        <ThemeProvider>
          <CarrinhoProvider>
            <App />
          </CarrinhoProvider>
        </ThemeProvider>
      </BrowserRouter>
    </React.StrictMode>
  );
}
