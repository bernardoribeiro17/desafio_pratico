import React from 'react';
import { Link } from 'react-router-dom';
import { useDepoimentos } from '../hooks/useDepoimentos';

const Home: React.FC = () => {
  const { depoimentos, carregando, erro } = useDepoimentos();

  return (
    <div className="text-center mt-5">
      <h1 className="display-4 text-primary fw-bold">Lançamento Oficial</h1>
      <p className="lead mt-3">
        Conheça o nosso novo produto inovador, desenvolvido para oferecer
        tecnologia, qualidade e desempenho incomparáveis.
      </p>

      <Link to="/produtos" className="btn btn-primary btn-lg mt-3">
        Ver Produtos
      </Link>

      <div className="container mt-5">
        <h2 className="text-center mb-4">O que nossos clientes dizem</h2>

        {carregando && (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Carregando...</span>
            </div>
          </div>
        )}

        {erro && (
          <div className="alert alert-danger" role="alert">
            {erro}
          </div>
        )}

        {!carregando && !erro && (
          <div className="row g-4">
            {depoimentos.map((d) => (
              <div className="col-md-4" key={d.id}>
                <div className="card shadow-sm h-100">
                  <div className="card-body">
                    <h6 className="card-title">{d.name}</h6>
                    <p className="card-text">{d.body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
