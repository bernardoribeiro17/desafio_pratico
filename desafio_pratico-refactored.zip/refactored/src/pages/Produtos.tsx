import React, { useState } from 'react';
import { useCarrinho } from '../context/CarrinhoContext';
import Carrinho from '../components/Carrinho';

const sampleProducts = [
  {
    id: 1,
    nome: 'Smartphone XPro',
    descricao: 'Tela AMOLED 6.5", 128GB, câmera 50MP.',
    preco: 2500,
    img: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600',
  },
  {
    id: 2,
    nome: 'Notebook UltraTech',
    descricao: 'i7, 16GB RAM, SSD 512GB.',
    preco: 4500,
    img: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600',
  },
  {
    id: 3,
    nome: 'Fone Bluetooth Pro',
    descricao: 'Cancelamento de ruído ativo, bateria 30h.',
    preco: 350,
    img: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=600',
  },
];

const CardProduto: React.FC<{ produto: (typeof sampleProducts)[0] }> = ({ produto }) => {
  const [qtd, setQtd] = useState(1);
  const { adicionarAoCarrinho } = useCarrinho();

  const handleAdicionar = () => {
    adicionarAoCarrinho({ nome: produto.nome, preco: produto.preco }, qtd);
  };

  return (
    <div className="card h-100 shadow">
      <img
        src={produto.img}
        className="card-img-top img-produto"
        alt={produto.nome}
      />
      <div className="card-body d-flex flex-column">
        <h5>{produto.nome}</h5>
        <p>{produto.descricao}</p>
        <p className="fw-bold text-success">
          R$ {produto.preco.toLocaleString('pt-BR')}
        </p>

        <label className="form-label mt-auto">Quantidade</label>
        <input
          type="number"
          className="form-control"
          value={qtd}
          min={1}
          onChange={(e) => setQtd(Math.max(1, parseInt(e.target.value) || 1))}
        />

        <button
          type="button"
          className="btn btn-success mt-3 w-100"
          onClick={handleAdicionar}
        >
          Adicionar ao Carrinho
        </button>
      </div>
    </div>
  );
};

const Produtos: React.FC = () => {
  return (
    <div>
      <h2 className="text-center mb-4">Nossos Produtos</h2>

      <div className="row g-4">
        {sampleProducts.map((p) => (
          <div className="col-md-4" key={p.id}>
            <CardProduto produto={p} />
          </div>
        ))}
      </div>

      <Carrinho />
    </div>
  );
};

export default Produtos;
